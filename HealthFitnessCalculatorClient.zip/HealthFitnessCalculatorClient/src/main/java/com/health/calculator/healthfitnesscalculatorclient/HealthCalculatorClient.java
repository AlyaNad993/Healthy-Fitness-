package com.health.calculator.client;

import com.health.calculator.client.generated.*;
import jakarta.xml.ws.WebServiceException;

public class HealthCalculatorClient {
    
    private HealthCalculatorService service;
    private HealthCalculatorServicePortType port;
    
    public HealthCalculatorClient() {
        try {
            // Initialize service
            service = new HealthCalculatorService();
            port = service.getHealthCalculatorServicePort();
        } catch (WebServiceException e) {
            System.err.println("Error connecting to web service: " + e.getMessage());
        }
    }
    
    // Calculate age from ID
    public int calculateAge(String idNumber) {
        try {
            return port.calculateAge(idNumber);
        } catch (Exception e) {
            System.err.println("Error calculating age: " + e.getMessage());
            return -1;
        }
    }
    
    // Calculate BMI
    public HealthResults calculateBMI(double weight, double height) {
        try {
            return port.calculateBMI(weight, height);
        } catch (Exception e) {
            System.err.println("Error calculating BMI: " + e.getMessage());
            return null;
        }
    }
    
    // Calculate Body Fat
    public double calculateBodyFat(String gender, double weight, double height, int age) {
        try {
            return port.calculateBodyFat(gender, weight, height, age);
        } catch (Exception e) {
            System.err.println("Error calculating body fat: " + e.getMessage());
            return -1;
        }
    }
    
    // Calculate BMR
    public double calculateBMR(String gender, double weight, double height, int age) {
        try {
            return port.calculateBMR(gender, weight, height, age);
        } catch (Exception e) {
            System.err.println("Error calculating BMR: " + e.getMessage());
            return -1;
        }
    }
    
    // Calculate Daily Calories
    public double calculateDailyCalories(double bmr, double activityLevel) {
        try {
            return port.calculateDailyCalories(bmr, activityLevel);
        } catch (Exception e) {
            System.err.println("Error calculating daily calories: " + e.getMessage());
            return -1;
        }
    }
    
    // Calculate all metrics
    public HealthResults calculateAllMetrics(UserData userData) {
        try {
            return port.calculateAllMetrics(userData);
        } catch (Exception e) {
            System.err.println("Error calculating all metrics: " + e.getMessage());
            return null;
        }
    }
    
    // Test method
    public static void main(String[] args) {
        HealthCalculatorClient client = new HealthCalculatorClient();
        
        // Test BMI calculation
        HealthResults bmiResult = client.calculateBMI(70, 175);
        if (bmiResult != null) {
            System.out.println("BMI: " + bmiResult.getBmi());
            System.out.println("Category: " + bmiResult.getBmiCategory());
        }
        
        // Test age calculation
        int age = client.calculateAge("950101-01-1234");
        System.out.println("Age: " + age);
        
        // Test complete calculation
        UserData user = new UserData();
        user.setName("John Doe");
        user.setIdNumber("950101-01-1234");
        user.setGender("male");
        user.setWeight(70);
        user.setHeight(175);
        user.setAge(age);
        user.setActivityLevel(1.55);
        
        HealthResults results = client.calculateAllMetrics(user);
        if (results != null) {
            System.out.println("\n=== Complete Health Report ===");
            System.out.println("BMI: " + results.getBmi() + " (" + results.getBmiCategory() + ")");
            System.out.println("Body Fat: " + results.getBodyFatPercentage() + "%");
            System.out.println("BMR: " + results.getBmr() + " calories/day");
            System.out.println("Daily Calories: " + results.getDailyCalories() + " calories/day");
        }
    }
}