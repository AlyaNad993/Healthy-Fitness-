package org.healthfitness;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.soap.SOAPFaultException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import java.time.LocalDate;
import java.time.Period;

@WebService(serviceName = "HealthService")
public class HealthService {

   @WebMethod(operationName = "displayUserInfo")
public String displayUserInfo(
        @WebParam(name = "name") String name,
        @WebParam(name = "ic") String ic,
        @WebParam(name = "gender") String gender,
        @WebParam(name = "weightKg") double weightKg,
        @WebParam(name = "heightCm") double heightCm) {

    try {
        // Semakan awal IC
        if (ic == null || ic.length() < 6) {
            throw new IllegalArgumentException("IC must have at least 6 characters for birthdate.");
        }

        int age = determineAge(ic); // Andaian: tarikhnya pada 6 digit pertama
        return String.format(
                "Name: %s\nID: %s\nGender: %s\nWeight: %.2f kg\nHeight: %.2f cm\nAge: %d years",
                name, ic, gender, weightKg, heightCm, age);

    } catch (Exception ex) {
        // Tangkap semua exception dan pulangkan sebagai teks biasa
        return "Error processing user info: " + ex.getMessage();
    }
}



    // 2. Tentukan umur berdasarkan IC
    @WebMethod(operationName = "determineAge")
    public int determineAge(@WebParam(name = "ic") String ic) {
    try {
        if (ic == null || ic.length() < 6) {
            throw new Exception("IC must be at least 6 characters for date of birth parsing.");
        }
        String dobStr = ic.substring(0, 6);
        int yearPrefix = Integer.parseInt(dobStr.substring(0, 2));
        int year = (yearPrefix <= 25) ? 2000 + yearPrefix : 1900 + yearPrefix;
        int month = Integer.parseInt(dobStr.substring(2, 4));
        int day = Integer.parseInt(dobStr.substring(4, 6));

        LocalDate birthDate = LocalDate.of(year, month, day);
        LocalDate today = LocalDate.now();
        if (birthDate.isAfter(today)) {
            throw new Exception("Date of birth in IC is after today's date.");
        }
        return Period.between(birthDate, today).getYears();
    } catch (Exception e) {
        throw createSOAPFault("Invalid IC format or date: " + e.getMessage());
    }
}


@WebMethod(operationName = "calculateBMI")
public String calculateBMI(
        @WebParam(name = "weightKg") double weightKg,
        @WebParam(name = "heightCm") double heightCm) {
    if (weightKg <= 0 || heightCm <= 0) {
        throw createSOAPFault("Weight and height must be positive numbers.");
    }

    double heightM = heightCm / 100.0;
    double bmi = weightKg / (heightM * heightM);
    double roundedBMI = Math.round(bmi * 100.0) / 100.0;

    String category;
    if (bmi < 18.5) {
        category = "Underweight";
    } else if (bmi < 24.9) {
        category = "Normal";
    } else if (bmi < 29.9) {
        category = "Overweight";
    } else {
        category = "Obese";
    }

    return "BMI: " + roundedBMI + " (" + category + ")";
}


    // 4. Kira Body Fat Percentage
    @WebMethod(operationName = "calculateBodyFatPercentage")
    public double calculateBodyFatPercentage(
            @WebParam(name = "gender") String gender,
            @WebParam(name = "bmi") double bmi,
            @WebParam(name = "age") int age) {
        if (gender == null || (!gender.equalsIgnoreCase("male") && !gender.equalsIgnoreCase("female"))) {
            throw createSOAPFault("Gender must be 'male' or 'female'.");
        }
        int genderVal = gender.equalsIgnoreCase("male") ? 1 : 0;
        double bodyFat = (1.20 * bmi) + (0.23 * age) - (10.8 * genderVal) - 5.4;
        return Math.round(bodyFat * 100.0) / 100.0;
    }

    // 5. Kira Calories Burn Rate
    @WebMethod(operationName = "calculateCaloriesBurnRate")
    public double calculateCaloriesBurnRate(
            @WebParam(name = "gender") String gender,
            @WebParam(name = "weightKg") double weightKg,
            @WebParam(name = "age") int age,
            @WebParam(name = "durationMinutes") double durationMinutes,
            @WebParam(name = "met") double met) {
        if (weightKg <= 0 || age <= 0 || durationMinutes <= 0 || met <= 0) {
            throw createSOAPFault("Weight, age, duration, and MET must be positive values.");
        }
        double durationHours = durationMinutes / 60.0;
        double calories = met * weightKg * durationHours;
        return Math.round(calories * 100.0) / 100.0;
    }

    // 6. Cadangan masa tidur
    @WebMethod(operationName = "recommendSleepHours")
    public String recommendSleepHours(@WebParam(name = "age") int age) {
        if (age <= 0) {
            throw createSOAPFault("Age must be positive.");
        }
        if (age <= 12) return "Recommended sleep: 9-12 hours (Children)";
        else if (age <= 18) return "Recommended sleep: 8-10 hours (Teenagers)";
        else if (age <= 64) return "Recommended sleep: 7-9 hours (Adults)";
        else return "Recommended sleep: 7-8 hours (Older adults)";
    }

    // 7. Kitaran haid, ovulasi & hari subur
    @WebMethod(operationName = "calculateMenstrualCycle")
    public String calculateMenstrualCycle(
            @WebParam(name = "startDate") String startDateStr,
            @WebParam(name = "endDate") String endDateStr) {

        try {
            LocalDate startDate = LocalDate.parse(startDateStr);
            LocalDate endDate = LocalDate.parse(endDateStr);

            if (endDate.isBefore(startDate)) {
                throw new IllegalArgumentException("End date must be after start date.");
            }

            int periodLength = Period.between(startDate, endDate).getDays() + 1;
            int estimatedCycleLength = 28;
            LocalDate nextPeriodStart = startDate.plusDays(estimatedCycleLength);
            LocalDate ovulationDate = nextPeriodStart.minusDays(14);
            LocalDate fertileStart = ovulationDate.minusDays(5);
            LocalDate fertileEnd = ovulationDate.plusDays(1);

            return String.format(
                    "Estimated Next Period by Date: %s\n" +
                    "Ovulation Day by Date: %s\n" +
                    "Fertile Window by Date: %s to %s",
                    nextPeriodStart,
                    ovulationDate,
                    fertileStart,
                    fertileEnd
            );
        } catch (Exception e) {
            throw createSOAPFault("Invalid date format or logic: " + e.getMessage());
        }
    }

    // 8. Bina SOAP fault exception
    private SOAPFaultException createSOAPFault(String message) {
        try {
            SOAPFault fault = SOAPFactory.newInstance().createFault();
            fault.setFaultString(message);
            return new SOAPFaultException(fault);
        } catch (Exception e) {
            throw new RuntimeException("Error creating SOAP fault: " + e.getMessage());
        }
    }
}
